PUNTI DI MODIFICA PER NUOVO LINKER (ARM-NONE-EABI)

MAKEFILE

definizione variabili: 14, 15, 16
modifica flag linking: 118
modifica linker: 152

MAKEFILE.INC

cambio opt. ottimizzazione: -O0